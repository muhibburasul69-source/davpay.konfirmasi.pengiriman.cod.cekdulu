# Design Brief

## Direction

RekberinAja — a mobile-first Indonesian escrow (rekening bersama) landing page with a vibrant royal-blue gradient hero, yellow highlight accents, and white rounded cards that build immediate trust.

## Tone

Clean, professional, trust-oriented financial aesthetic — bold sans-serif headings over a confident royal-blue gradient, softened by white cards and a single bright-yellow highlight.

## Differentiation

The yellow-marked "Aman & Terpercaya" tagline on a vivid blue gradient instantly signals safety, while the white "Buat Rekber" form card floats as the clear conversion focal point.

## Color Palette

| Token      | OKLCH           | Role                                   |
| ---------- | --------------- | -------------------------------------- |
| background | 0.96 0.008 255  | light blue-tinted page backdrop        |
| foreground | 0.17 0.04 255   | deep navy text                         |
| card       | 1.0 0 0         | white form/step surfaces               |
| primary    | 0.55 0.23 255   | royal blue CTAs, header gradient       |
| accent     | 0.86 0.18 95    | bright yellow highlight                |
| muted      | 0.95 0.01 255   | light gray fill                        |
| border     | 0.9 0.015 255   | light gray borders                     |

## Typography

- Display: Space Grotesk — hero title, section headings, bold geometric trust
- Body: DM Sans — form labels, inputs, paragraphs, UI copy
- Scale: hero `text-4xl font-bold tracking-tight`, h2 `text-2xl font-bold`, label `text-sm font-semibold`, body `text-base`

## Elevation & Depth

White cards sit on the light page with subtle `shadow-card`; the hero uses a layered blue gradient (`--gradient-primary`) with a decorative geometric line pattern overlay.

## Structural Zones

| Zone    | Background                    | Border   | Notes                              |
| ------- | ----------------------------- | -------- | ---------------------------------- |
| Header  | `bg-gradient-primary`         | —        | sticky, white logo + hamburger     |
| Hero    | `bg-gradient-primary`         | —        | decorative line pattern overlay    |
| Content | `bg-background`               | —        | form card + Cara Kerja alternating |
| Footer  | `bg-muted/40`                 | border-t | brand + copyright                  |

## Spacing & Rhythm

Mobile-first with generous section gaps (py-12/16), tight 8px micro-spacing inside the form card, and centered max-w-md column for the landing flow.

## Component Patterns

- Buttons: full-width royal blue, rounded-xl, white text, hover darkens via gradient
- Cards: white, rounded-2xl, `shadow-card`, light gray border
- Badges: yellow accent pill for the "Aman & Terpercaya" tagline; blue circular numbered badges for steps

## Motion

- Entrance: `animate-fade-up` on hero and form card (0.5s)
- Hover: buttons lift with `transition-smooth` (0.3s)
- Decorative: floating chat FAB uses `animate-float` (3s)

## Constraints

- Match attached screenshot layout and styling exactly
- Indonesian UI copy throughout
- Royal blue (#0066FF) primary, bright yellow accent, white rounded cards, light gray borders
- Handle Indonesian Rupiah (IDR) live formatting

## Signature Detail

The single yellow-highlighted "Aman & Terpercaya" line on the royal-blue gradient hero is the memorable trust anchor that sells the whole escrow promise at a glance.
