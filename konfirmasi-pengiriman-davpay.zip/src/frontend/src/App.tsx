import { CaraKerjaSection } from "./components/CaraKerjaSection";
import { HeroSection } from "./components/HeroSection";
import { Layout } from "./components/Layout";
import { RekberForm } from "./components/RekberForm";

export default function App() {
  return (
    <Layout>
      <HeroSection />
      <div className="relative z-10 -mt-16 px-6">
        <RekberForm />
      </div>
      <CaraKerjaSection />
    </Layout>
  );
}
