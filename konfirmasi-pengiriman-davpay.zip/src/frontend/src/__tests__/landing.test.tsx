import "@testing-library/jest-dom/vitest";
import {
  configure,
  fireEvent,
  render,
  screen,
  within,
} from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";

import App from "../App";

// The generated components expose `data-ocid` hooks rather than semantic
// test ids; point Testing Library at them for stable, intent-revealing queries.
configure({ testIdAttribute: "data-ocid" });

describe("Davpay landing page", () => {
  it("loads without a blank screen and renders the header, hero, form, steps, footer and chat", () => {
    render(<App />);

    // Header
    const header = screen.getByRole("banner");
    expect(header).toBeInTheDocument();
    expect(within(header).getByText("Davpay")).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: "Buka menu" }),
    ).toBeInTheDocument();

    // Hero
    expect(
      screen.getByRole("heading", { level: 1, name: "Davpay" }),
    ).toBeInTheDocument();
    expect(screen.getByText("Aman & Terpercaya")).toBeInTheDocument();
    expect(
      screen.getByText(
        "Rekening bersama untuk transaksi jual beli & jasa online kamu",
      ),
    ).toBeInTheDocument();
    expect(screen.getByText("Aman • Nyaman • Terlindungi")).toBeInTheDocument();

    // Form
    const formCard = screen.getByTestId("rekber.card");
    expect(
      within(formCard).getByText("Buat Rekber", {
        selector: '[data-slot="card-title"]',
      }),
    ).toBeInTheDocument();
    expect(screen.getByTestId("rekber.role_select")).toBeInTheDocument();
    expect(screen.getByTestId("rekber.category_select")).toBeInTheDocument();
    expect(screen.getByTestId("rekber.product_input")).toBeInTheDocument();
    expect(screen.getByTestId("rekber.amount_input")).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: /Buat Rekber/ }),
    ).toBeInTheDocument();

    // Cara Kerja
    expect(
      screen.getByRole("heading", { name: "Cara Kerja" }),
    ).toBeInTheDocument();
    expect(screen.getByText("Isi Form Rekber")).toBeInTheDocument();
    expect(screen.getByText("Masuk Akun")).toBeInTheDocument();
    expect(screen.getByText("Kirim Pesanan")).toBeInTheDocument();

    // Footer
    expect(screen.getByRole("contentinfo")).toBeInTheDocument();

    // Floating chat
    expect(
      screen.getByRole("button", { name: "Buka chat" }),
    ).toBeInTheDocument();
  });

  it("shows a red gradient header with the red logo image beside the wordmark and hamburger menu", () => {
    render(<App />);

    const header = screen.getByRole("banner");
    expect(header).toHaveClass("bg-gradient-primary");
    expect(header).toHaveClass("sticky");

    // Red logo image sits to the left of the Davpay wordmark, referenced from
    // the public assets directory.
    const logo = within(header).getByRole("img", { name: "Logo Davpay" });
    expect(logo).toHaveAttribute("src", "/assets/images/davpay-logo.png");
    expect(logo).toBeInTheDocument();

    const brand = within(header).getByText("Davpay");
    expect(brand).toBeInTheDocument();
    // The logo precedes the wordmark in the header's brand row.
    expect(logo.compareDocumentPosition(brand)).toBe(
      Node.DOCUMENT_POSITION_FOLLOWING,
    );

    // Hamburger menu button
    expect(
      within(header).getByRole("button", { name: "Buka menu" }),
    ).toBeInTheDocument();
  });

  it("renders the hero with a yellow-highlighted tagline and trust badges", () => {
    render(<App />);

    const hero = screen.getByTestId("hero.section");
    expect(hero).toHaveClass("bg-gradient-primary");

    const tagline = within(hero).getByText("Aman & Terpercaya");
    expect(tagline).toHaveClass("bg-accent");

    expect(
      within(hero).getByText("Aman • Nyaman • Terlindungi"),
    ).toBeInTheDocument();
  });

  it("formats the IDR amount input with live Rupiah formatting", async () => {
    const user = userEvent.setup();
    render(<App />);

    const amountInput = screen.getByTestId(
      "rekber.amount_input",
    ) as HTMLInputElement;
    await user.type(amountInput, "1500000");

    // id-ID currency formatting groups the digits with dots and prefixes "Rp";
    // assert the formatted value loosely (the separator after "Rp" varies).
    expect(amountInput.value).toMatch(/^Rp\s*1\.500\.000$/);
  });

  it("shows Indonesian validation errors on empty submit and does not proceed", async () => {
    const user = userEvent.setup();
    render(<App />);

    await user.click(screen.getByRole("button", { name: /Buat Rekber/ }));

    expect(screen.getByTestId("rekber.role_error")).toHaveTextContent(
      "Pilih peran kamu terlebih dahulu.",
    );
    expect(screen.getByTestId("rekber.category_error")).toHaveTextContent(
      "Pilih kategori layanan.",
    );
    expect(screen.getByTestId("rekber.product_error")).toHaveTextContent(
      "Nama produk wajib diisi.",
    );
    expect(screen.getByTestId("rekber.amount_error")).toHaveTextContent(
      "Masukkan jumlah biaya yang valid.",
    );

    // Still on the form, no confirmation state.
    expect(
      screen.queryByTestId("rekber.success_state"),
    ).not.toBeInTheDocument();
  });

  it("shows an account confirmation step on a valid submit and the success card only after confirming", async () => {
    const user = userEvent.setup();
    render(<App />);

    // Radix Select's trigger calls preventDefault on pointerdown, which makes
    // userEvent.click/keyboard hang under jsdom. Radix also renders a hidden
    // native <select> for accessibility; drive that directly with a change
    // event, which Radix forwards to onValueChange.
    const setSelect = (value: string) => {
      const nativeSelect = Array.from(document.querySelectorAll("select")).find(
        (s) => Array.from(s.options).some((o) => o.value === value),
      );
      fireEvent.change(nativeSelect!, { target: { value } });
    };

    setSelect("pembeli");
    setSelect("jual-beli");

    await user.type(
      screen.getByTestId("rekber.product_input"),
      "iPhone 13 Pro Max",
    );
    await user.type(screen.getByTestId("rekber.amount_input"), "15000000");

    await user.click(screen.getByRole("button", { name: /Buat Rekber/ }));

    // Valid submit now lands on the account confirmation step, not the success
    // card. It uses Indonesian labels and the existing Davpay card styling.
    const confirmCard = screen.getByTestId("rekber.confirm_state");
    expect(confirmCard).toBeInTheDocument();
    expect(
      within(confirmCard).getByText("Konfirmasi Akun", {
        selector: '[data-slot="card-title"]',
      }),
    ).toBeInTheDocument();
    expect(screen.getByTestId("rekber.email_input")).toBeInTheDocument();
    expect(screen.getByTestId("rekber.password_input")).toBeInTheDocument();
    expect(screen.getByLabelText("Email")).toBeInTheDocument();
    expect(screen.getByLabelText("Kata Sandi")).toBeInTheDocument();
    expect(confirmCard).toHaveClass("rounded-2xl");
    expect(confirmCard).toHaveClass("shadow-card");

    // The success card is not shown yet.
    expect(
      screen.queryByTestId("rekber.success_state"),
    ).not.toBeInTheDocument();

    // Confirming with an empty email/password shows Indonesian validation
    // errors and stays on the confirmation step.
    await user.click(screen.getByRole("button", { name: /Konfirmasi/ }));
    expect(screen.getByTestId("rekber.email_error")).toHaveTextContent(
      "Email wajib diisi.",
    );
    expect(screen.getByTestId("rekber.password_error")).toHaveTextContent(
      "Kata sandi wajib diisi.",
    );
    expect(
      screen.queryByTestId("rekber.success_state"),
    ).not.toBeInTheDocument();

    // Filling in a valid email and password and confirming shows the success
    // card.
    await user.type(
      screen.getByTestId("rekber.email_input"),
      "user@example.com",
    );
    await user.type(screen.getByTestId("rekber.password_input"), "rahasia123");
    await user.click(screen.getByRole("button", { name: /Konfirmasi/ }));

    expect(screen.getByTestId("rekber.success_state")).toBeInTheDocument();
    expect(
      screen.getByRole("heading", { name: "Permintaan Rekber Diterima!" }),
    ).toBeInTheDocument();
  });

  it("renders the three numbered Cara Kerja steps", () => {
    render(<App />);

    const section = screen.getByTestId("carakerja.section");
    expect(within(section).getByTestId("carakerja.item.1")).toHaveTextContent(
      "Isi Form Rekber",
    );
    expect(within(section).getByTestId("carakerja.item.2")).toHaveTextContent(
      "Masuk Akun",
    );
    expect(within(section).getByTestId("carakerja.item.3")).toHaveTextContent(
      "Kirim Pesanan",
    );
  });

  it("shows a floating chat bubble button in the bottom right with a red badge", () => {
    render(<App />);

    const chatButton = screen.getByRole("button", { name: "Buka chat" });
    expect(chatButton).toBeInTheDocument();
    expect(chatButton.closest("div")).toHaveClass("fixed");
    expect(chatButton.closest("div")).toHaveClass("bottom-5");
    expect(chatButton.closest("div")).toHaveClass("right-5");
    expect(chatButton).toHaveClass("bg-gradient-primary");
  });
});
