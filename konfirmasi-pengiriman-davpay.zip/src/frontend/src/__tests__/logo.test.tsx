import "@testing-library/jest-dom/vitest";
import {
  cleanup,
  configure,
  render,
  screen,
  within,
} from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";

afterEach(cleanup);

import App from "../App";

// The generated components expose `data-ocid` hooks rather than semantic
// test ids; point Testing Library at them for stable, intent-revealing queries.
configure({ testIdAttribute: "data-ocid" });

// Cover for the Davpay logo requirement: the header must render the logo image
// to the left of the 'Davpay' wordmark, loading from the public assets
// directory with correct sizing.
describe("Davpay header logo", () => {
  it("renders the logo image to the left of the wordmark with correct sizing", () => {
    render(<App />);

    const header = screen.getByRole("banner");
    const logo = within(header).getByRole("img", { name: "Logo Davpay" });

    // Loads from the public assets directory at runtime.
    expect(logo).toHaveAttribute("src", "/assets/images/davpay-logo.png");
    expect(logo).toBeInTheDocument();
    expect(logo).toBeVisible();

    // Correct sizing: a 36px (size-9) rounded app-icon tile.
    expect(logo).toHaveClass("size-9");
    expect(logo).toHaveClass("rounded-xl");

    // The logo precedes the wordmark in the header's brand row.
    const brand = within(header).getByText("Davpay");
    expect(logo.compareDocumentPosition(brand)).toBe(
      Node.DOCUMENT_POSITION_FOLLOWING,
    );
  });
});
