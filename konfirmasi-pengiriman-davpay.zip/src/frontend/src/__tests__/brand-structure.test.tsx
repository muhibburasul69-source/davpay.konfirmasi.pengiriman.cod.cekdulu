import "@testing-library/jest-dom/vitest";
import {
  cleanup,
  configure,
  render,
  screen,
  within,
} from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";

afterEach(cleanup);

import App from "../App";

// The generated components expose `data-ocid` hooks rather than semantic
// test ids; point Testing Library at them for stable, intent-revealing queries.
configure({ testIdAttribute: "data-ocid" });

// Characterization baseline for the brand rename (RekberinAja -> Davpay).
// The specific brand string is intentionally changing, so these tests protect
// the structural behavior of the brand-affected components (Header, Hero,
// Footer) without freezing the old brand name as a baseline.
describe("brand-affected component structure", () => {
  it("keeps a single brand text element in the header beside the logo image", () => {
    render(<App />);

    const header = screen.getByRole("banner");
    // The brand sits beside the logo image; assert it exists and is visible
    // text without pinning the exact brand string.
    const brand = within(header).getByText(/^\S+$/);
    expect(brand).toBeInTheDocument();
    expect(brand).toHaveClass("font-display");

    // The logo image is referenced from the public assets directory.
    const logo = within(header).getByRole("img", { name: "Logo Davpay" });
    expect(logo).toHaveAttribute("src", "/assets/images/davpay-logo.png");
  });

  it("keeps the hero's level-1 heading and tagline", () => {
    render(<App />);

    const hero = screen.getByTestId("hero.section");
    const heading = within(hero).getByRole("heading", { level: 1 });
    expect(heading).toBeInTheDocument();
    expect(heading).toHaveClass("font-display");

    // The tagline and trust badges are not part of the brand rename.
    expect(within(hero).getByText("Aman & Terpercaya")).toBeInTheDocument();
    expect(
      within(hero).getByText("Aman • Nyaman • Terlindungi"),
    ).toBeInTheDocument();
  });

  it("keeps the footer brand element, tagline and copyright", () => {
    render(<App />);

    const footer = screen.getByRole("contentinfo");
    // Brand text element beside the footer logo, without pinning the string.
    // The brand span is the only `font-display` text in the footer.
    const brand = within(footer).getByText(/^\S+$/, {
      selector: ".font-display",
    });
    expect(brand).toBeInTheDocument();

    // Non-brand footer content that must survive the rename.
    expect(
      within(footer).getByText(
        "Rekening bersama untuk transaksi jual beli & jasa online kamu.",
      ),
    ).toBeInTheDocument();
    expect(within(footer).getByText(/© \d{4}\./)).toBeInTheDocument();
  });
});
