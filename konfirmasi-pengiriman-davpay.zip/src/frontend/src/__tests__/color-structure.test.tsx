import "@testing-library/jest-dom/vitest";
import {
  cleanup,
  configure,
  render,
  screen,
  within,
} from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";

afterEach(cleanup);

import App from "../App";

// The generated components expose `data-ocid` hooks rather than semantic
// test ids; point Testing Library at them for stable, intent-revealing queries.
configure({ testIdAttribute: "data-ocid" });

// Characterization baseline for the primary-color change (#0066FF blue -> red).
// The blue gradient/primary classes are intentionally changing, so these tests
// protect the *structural* behavior of the color-affected components (Header,
// Hero, FloatingChat, Footer, CaraKerja) without freezing the blue color as a
// baseline. The yellow accent (bg-accent) is not part of the change and is
// asserted here as behavior that must survive.
describe("color-affected component structure", () => {
  it("keeps the header sticky with the brand and hamburger menu", () => {
    render(<App />);

    const header = screen.getByRole("banner");
    expect(header).toHaveClass("sticky");
    expect(within(header).getByText("Davpay")).toBeInTheDocument();
    expect(
      within(header).getByRole("button", { name: "Buka menu" }),
    ).toBeInTheDocument();
  });

  it("keeps the hero's yellow accent tagline and trust badges", () => {
    render(<App />);

    const hero = screen.getByTestId("hero.section");
    // The yellow accent is not part of the blue->red change.
    const tagline = within(hero).getByText("Aman & Terpercaya");
    expect(tagline).toHaveClass("bg-accent");
    expect(
      within(hero).getByText("Aman • Nyaman • Terlindungi"),
    ).toBeInTheDocument();
  });

  it("keeps the floating chat button fixed to the bottom right", () => {
    render(<App />);

    const chatButton = screen.getByRole("button", { name: "Buka chat" });
    expect(chatButton.closest("div")).toHaveClass("fixed");
    expect(chatButton.closest("div")).toHaveClass("bottom-5");
    expect(chatButton.closest("div")).toHaveClass("right-5");
  });

  it("keeps the footer brand, tagline and copyright", () => {
    render(<App />);

    const footer = screen.getByRole("contentinfo");
    expect(within(footer).getByText("Davpay")).toBeInTheDocument();
    expect(
      within(footer).getByText(
        "Rekening bersama untuk transaksi jual beli & jasa online kamu.",
      ),
    ).toBeInTheDocument();
    expect(within(footer).getByText(/© \d{4}\./)).toBeInTheDocument();
  });

  it("keeps the Cara Kerja step number circles", () => {
    render(<App />);

    const section = screen.getByTestId("carakerja.section");
    expect(within(section).getByTestId("carakerja.item.1")).toHaveTextContent(
      "Isi Form Rekber",
    );
    expect(within(section).getByTestId("carakerja.item.2")).toHaveTextContent(
      "Masuk Akun",
    );
    expect(within(section).getByTestId("carakerja.item.3")).toHaveTextContent(
      "Kirim Pesanan",
    );
  });
});
