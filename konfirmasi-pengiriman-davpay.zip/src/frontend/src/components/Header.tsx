import { Menu } from "lucide-react";

export function Header() {
  return (
    <header className="sticky top-0 z-40 bg-gradient-primary shadow-subtle">
      <div className="mx-auto flex h-16 max-w-md items-center justify-between px-5">
        <div className="flex items-center gap-2.5">
          <img
            src="/assets/images/davpay-logo.png"
            alt="Logo Davpay"
            className="size-9 rounded-xl object-cover shadow-sm ring-1 ring-white/20"
          />
          <span className="font-display text-lg font-bold tracking-tight text-white">
            Davpay
          </span>
        </div>

        <button
          type="button"
          aria-label="Buka menu"
          data-ocid="header.menu_button"
          className="flex size-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/15 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/60"
        >
          <Menu className="size-6" aria-hidden="true" />
        </button>
      </div>
    </header>
  );
}
