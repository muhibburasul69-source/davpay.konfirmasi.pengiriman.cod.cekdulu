import { MessageCircle } from "lucide-react";

/**
 * Decorative floating chat bubble. The button is visual only — no live chat
 * conversation is wired up.
 */
export function FloatingChat() {
  return (
    <div className="fixed bottom-5 right-5 z-50">
      <button
        type="button"
        aria-label="Buka chat"
        data-ocid="floating_chat.button"
        className="relative flex size-14 items-center justify-center rounded-full bg-gradient-primary text-white shadow-elevated transition-transform hover:scale-105 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
      >
        <MessageCircle className="size-7" aria-hidden="true" />
        <span
          aria-hidden="true"
          className="absolute -right-0.5 -top-0.5 flex size-5 items-center justify-center rounded-full bg-destructive text-[11px] font-bold text-destructive-foreground ring-2 ring-background"
        >
          1
        </span>
      </button>
    </div>
  );
}
