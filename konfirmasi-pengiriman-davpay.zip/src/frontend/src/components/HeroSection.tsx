import { ShieldCheck } from "lucide-react";

const trustBadges = ["Aman", "Nyaman", "Terlindungi"];

export function HeroSection() {
  return (
    <section
      data-ocid="hero.section"
      className="relative overflow-hidden bg-gradient-primary text-white"
    >
      {/* Decorative geometric line pattern */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-20"
      >
        <svg
          aria-hidden="true"
          focusable="false"
          className="h-full w-full"
          viewBox="0 0 400 400"
          preserveAspectRatio="xMidYMid slice"
          fill="none"
        >
          <path
            d="M0 80 H400 M0 160 H400 M0 240 H400 M0 320 H400"
            stroke="white"
            strokeWidth="1"
          />
          <path
            d="M80 0 V400 M160 0 V400 M240 0 V400 M320 0 V400"
            stroke="white"
            strokeWidth="1"
          />
          <circle cx="80" cy="80" r="3" fill="white" />
          <circle cx="240" cy="160" r="3" fill="white" />
          <circle cx="320" cy="320" r="3" fill="white" />
          <circle cx="160" cy="240" r="3" fill="white" />
        </svg>
      </div>

      <div className="relative mx-auto flex max-w-md flex-col items-center px-6 pb-24 pt-12 text-center">
        <h1 className="font-display text-4xl font-bold tracking-tight text-white">
          Davpay
        </h1>

        <span className="mt-4 inline-flex items-center rounded-full bg-accent px-4 py-1.5 text-sm font-bold text-accent-foreground shadow-sm">
          Aman &amp; Terpercaya
        </span>

        <p className="mt-4 max-w-xs text-base leading-relaxed text-white/90">
          Rekening bersama untuk transaksi jual beli &amp; jasa online kamu
        </p>

        <div className="mt-6 flex items-center gap-2 text-sm font-medium text-white/95">
          <ShieldCheck className="size-4" aria-hidden="true" />
          <span>{trustBadges.join(" • ")}</span>
        </div>
      </div>
    </section>
  );
}
