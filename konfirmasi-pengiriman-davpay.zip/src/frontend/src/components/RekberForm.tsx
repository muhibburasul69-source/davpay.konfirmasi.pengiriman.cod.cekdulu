import { ArrowLeft, CheckCircle2, Send } from "lucide-react";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { formatIDR } from "@/lib/format";

const roleOptions = [
  { value: "pembeli", label: "Saya Pembeli" },
  { value: "penjual", label: "Saya Penjual" },
];

const categoryOptions = [
  { value: "jual-beli", label: "Jual Beli Barang" },
  { value: "jasa", label: "Jasa / Freelance" },
  { value: "game", label: "Top Up Game" },
  { value: "tiket", label: "Tiket & Reservasi" },
  { value: "lainnya", label: "Lainnya" },
];

type Errors = {
  role?: string;
  category?: string;
  productName?: string;
  amount?: string;
};

type AccountErrors = {
  email?: string;
  password?: string;
};

export function RekberForm() {
  const [role, setRole] = useState<string>("");
  const [category, setCategory] = useState<string>("");
  const [productName, setProductName] = useState<string>("");
  const [amount, setAmount] = useState<string>("");
  const [errors, setErrors] = useState<Errors>({});
  const [confirming, setConfirming] = useState(false);
  const [email, setEmail] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [accountErrors, setAccountErrors] = useState<AccountErrors>({});
  const [submitted, setSubmitted] = useState(false);

  const numericAmount = Number(amount.replace(/[^\d]/g, "")) || 0;

  function handleAmountChange(raw: string) {
    const digits = raw.replace(/[^\d]/g, "").slice(0, 12);
    setAmount(digits ? formatIDR(Number(digits)) : "");
  }

  function validate(): Errors {
    const next: Errors = {};
    if (!role) next.role = "Pilih peran kamu terlebih dahulu.";
    if (!category) next.category = "Pilih kategori layanan.";
    if (!productName.trim()) next.productName = "Nama produk wajib diisi.";
    if (numericAmount <= 0) next.amount = "Masukkan jumlah biaya yang valid.";
    return next;
  }

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const next = validate();
    setErrors(next);
    if (Object.keys(next).length === 0) {
      setConfirming(true);
    }
  }

  function validateAccount(): AccountErrors {
    const next: AccountErrors = {};
    if (!email.trim()) next.email = "Email wajib diisi.";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()))
      next.email = "Masukkan alamat email yang valid.";
    if (!password) next.password = "Kata sandi wajib diisi.";
    else if (password.length < 6)
      next.password = "Kata sandi minimal 6 karakter.";
    return next;
  }

  function handleConfirm(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const next = validateAccount();
    setAccountErrors(next);
    if (Object.keys(next).length === 0) {
      setSubmitted(true);
    }
  }

  function resetAll() {
    setSubmitted(false);
    setConfirming(false);
    setRole("");
    setCategory("");
    setProductName("");
    setAmount("");
    setEmail("");
    setPassword("");
    setErrors({});
    setAccountErrors({});
  }

  if (submitted) {
    return (
      <Card
        data-ocid="rekber.success_state"
        className="mx-auto w-full max-w-md rounded-2xl border-border bg-card shadow-card"
      >
        <CardContent className="flex flex-col items-center px-6 py-10 text-center">
          <span className="flex size-16 items-center justify-center rounded-full bg-primary/10">
            <CheckCircle2 className="size-9 text-primary" aria-hidden="true" />
          </span>
          <h3 className="mt-5 font-display text-xl font-bold text-foreground">
            Permintaan Rekber Diterima!
          </h3>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            Terima kasih, permintaan rekber kamu sudah kami terima. Tim kami
            akan segera menghubungi kamu untuk melanjutkan transaksi.
          </p>
          <Button
            type="button"
            variant="outline"
            className="mt-6 w-full"
            data-ocid="rekber.reset_button"
            onClick={resetAll}
          >
            Buat Rekber Baru
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (confirming) {
    return (
      <Card
        data-ocid="rekber.confirm_state"
        className="mx-auto w-full max-w-md rounded-2xl border-border bg-card shadow-card"
      >
        <CardHeader className="px-6 pt-6">
          <CardTitle className="font-display text-xl font-bold text-foreground">
            Konfirmasi Akun
          </CardTitle>
          <CardDescription>
            Lengkapi detail akun kamu untuk melanjutkan permintaan rekber
          </CardDescription>
        </CardHeader>

        <CardContent className="px-6 pb-6">
          <form
            onSubmit={handleConfirm}
            noValidate
            className="flex flex-col gap-4"
          >
            <div className="flex flex-col gap-1.5">
              <Label
                htmlFor="email"
                className="text-sm font-medium text-foreground"
              >
                Email
              </Label>
              <Input
                id="email"
                data-ocid="rekber.email_input"
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="nama@email.com"
                className="h-11 rounded-lg border-input bg-background"
                aria-invalid={!!accountErrors.email}
              />
              {accountErrors.email && (
                <p
                  data-ocid="rekber.email_error"
                  className="text-xs text-destructive"
                >
                  {accountErrors.email}
                </p>
              )}
            </div>

            <div className="flex flex-col gap-1.5">
              <Label
                htmlFor="password"
                className="text-sm font-medium text-foreground"
              >
                Kata Sandi
              </Label>
              <Input
                id="password"
                data-ocid="rekber.password_input"
                type="password"
                autoComplete="new-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Minimal 6 karakter"
                className="h-11 rounded-lg border-input bg-background"
                aria-invalid={!!accountErrors.password}
              />
              {accountErrors.password && (
                <p
                  data-ocid="rekber.password_error"
                  className="text-xs text-destructive"
                >
                  {accountErrors.password}
                </p>
              )}
            </div>

            <Button
              type="submit"
              data-ocid="rekber.confirm_button"
              className="mt-1 h-12 w-full rounded-xl bg-primary text-base font-semibold text-primary-foreground shadow-elevated hover:bg-primary/90"
            >
              Konfirmasi
              <CheckCircle2 className="size-4" aria-hidden="true" />
            </Button>

            <Button
              type="button"
              variant="ghost"
              data-ocid="rekber.back_button"
              className="h-11 w-full rounded-xl text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground"
              onClick={() => {
                setConfirming(false);
                setAccountErrors({});
              }}
            >
              <ArrowLeft className="size-4" aria-hidden="true" />
              Kembali ke Form
            </Button>
          </form>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card
      data-ocid="rekber.card"
      className="mx-auto w-full max-w-md rounded-2xl border-border bg-card shadow-card"
    >
      <CardHeader className="px-6 pt-6">
        <CardTitle className="font-display text-xl font-bold text-foreground">
          Buat Rekber
        </CardTitle>
        <CardDescription>
          Isi detail transaksi kamu untuk memulai rekening bersama
        </CardDescription>
      </CardHeader>

      <CardContent className="px-6 pb-6">
        <form
          onSubmit={handleSubmit}
          noValidate
          className="flex flex-col gap-4"
        >
          <div className="flex flex-col gap-1.5">
            <Label
              htmlFor="role"
              className="text-sm font-medium text-foreground"
            >
              Peran
            </Label>
            <Select
              value={role}
              onValueChange={(v) => {
                // Radix Select fires onValueChange("") when the form is
                // submitted (it resets its hidden native <select>), which would
                // wipe the selected role right before validation. Ignore empty
                // resets — no role option has an empty value.
                if (v) setRole(v);
              }}
            >
              <SelectTrigger
                id="role"
                data-ocid="rekber.role_select"
                className="w-full rounded-lg border-input bg-background"
                aria-invalid={!!errors.role}
              >
                <SelectValue placeholder="Saya Pembeli" />
              </SelectTrigger>
              <SelectContent>
                {roleOptions.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.role && (
              <p
                data-ocid="rekber.role_error"
                className="text-xs text-destructive"
              >
                {errors.role}
              </p>
            )}
          </div>

          <div className="flex flex-col gap-1.5">
            <Label
              htmlFor="category"
              className="text-sm font-medium text-foreground"
            >
              Kategori
            </Label>
            <Select
              value={category}
              onValueChange={(v) => {
                // Same guard as the role select: ignore the empty-string reset
                // Radix fires on form submit so the chosen category survives
                // validation.
                if (v) setCategory(v);
              }}
            >
              <SelectTrigger
                id="category"
                data-ocid="rekber.category_select"
                className="w-full rounded-lg border-input bg-background"
                aria-invalid={!!errors.category}
              >
                <SelectValue placeholder="Pilih Salah Satu" />
              </SelectTrigger>
              <SelectContent>
                {categoryOptions.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.category && (
              <p
                data-ocid="rekber.category_error"
                className="text-xs text-destructive"
              >
                {errors.category}
              </p>
            )}
          </div>

          <div className="flex flex-col gap-1.5">
            <Label
              htmlFor="productName"
              className="text-sm font-medium text-foreground"
            >
              Nama Produk
            </Label>
            <Input
              id="productName"
              data-ocid="rekber.product_input"
              value={productName}
              onChange={(e) => setProductName(e.target.value)}
              placeholder="misal: iPhone 13 Pro Max"
              className="h-11 rounded-lg border-input bg-background"
              aria-invalid={!!errors.productName}
            />
            {errors.productName && (
              <p
                data-ocid="rekber.product_error"
                className="text-xs text-destructive"
              >
                {errors.productName}
              </p>
            )}
          </div>

          <div className="flex flex-col gap-1.5">
            <Label
              htmlFor="amount"
              className="text-sm font-medium text-foreground"
            >
              Jumlah Biaya
            </Label>
            <div className="relative">
              <span className="pointer-events-none absolute inset-y-0 left-3 flex items-center text-sm font-semibold text-muted-foreground">
                Rp
              </span>
              <Input
                id="amount"
                data-ocid="rekber.amount_input"
                inputMode="numeric"
                value={amount}
                onChange={(e) => handleAmountChange(e.target.value)}
                placeholder="0"
                className="h-11 rounded-lg border-input bg-background pl-10 text-right"
                aria-invalid={!!errors.amount}
              />
            </div>
            {errors.amount && (
              <p
                data-ocid="rekber.amount_error"
                className="text-xs text-destructive"
              >
                {errors.amount}
              </p>
            )}
          </div>

          <Button
            type="submit"
            data-ocid="rekber.submit_button"
            className="mt-1 h-12 w-full rounded-xl bg-primary text-base font-semibold text-primary-foreground shadow-elevated hover:bg-primary/90"
          >
            Buat Rekber
            <Send className="size-4" aria-hidden="true" />
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
