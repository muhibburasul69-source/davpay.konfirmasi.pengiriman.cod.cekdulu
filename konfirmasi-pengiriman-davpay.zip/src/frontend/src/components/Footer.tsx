import { ShoppingCart } from "lucide-react";

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-border bg-muted">
      <div className="mx-auto flex max-w-md flex-col items-center gap-3 px-5 py-8 text-center">
        <div className="flex items-center gap-2">
          <span className="flex size-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
            <ShoppingCart className="size-4" aria-hidden="true" />
          </span>
          <span className="font-display text-base font-bold text-foreground">
            Davpay
          </span>
        </div>
        <p className="text-sm text-muted-foreground">
          Rekening bersama untuk transaksi jual beli &amp; jasa online kamu.
        </p>
        <p className="text-xs text-muted-foreground">
          © {year}. Dibuat dengan ❤️ menggunakan{" "}
          <a
            href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(
              typeof window !== "undefined" ? window.location.hostname : "",
            )}`}
            target="_blank"
            rel="noreferrer"
            className="font-medium text-primary underline-offset-2 hover:underline"
          >
            caffeine.ai
          </a>
        </p>
      </div>
    </footer>
  );
}
