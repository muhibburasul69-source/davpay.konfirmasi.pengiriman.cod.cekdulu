const steps = [
  {
    number: 1,
    title: "Isi Form Rekber",
    description: "Lengkapi detail transaksi di atas",
  },
  {
    number: 2,
    title: "Masuk Akun",
    description: "Daftar/masuk dengan email kamu",
  },
  {
    number: 3,
    title: "Kirim Pesanan",
    description: "Data pengiriman & pesanan",
  },
];

export function CaraKerjaSection() {
  return (
    <section data-ocid="carakerja.section" className="bg-background px-6 py-10">
      <div className="mx-auto max-w-md">
        <h2 className="text-center font-display text-2xl font-bold text-foreground">
          Cara Kerja
        </h2>
        <p className="mt-2 text-center text-sm text-muted-foreground">
          Tiga langkah mudah untuk transaksi yang aman
        </p>

        <div className="mt-6 flex flex-col gap-4">
          {steps.map((step) => (
            <div
              key={step.number}
              data-ocid={`carakerja.item.${step.number}`}
              className="flex items-center gap-4 rounded-2xl border border-border bg-card p-4 shadow-card"
            >
              <span className="flex size-11 shrink-0 items-center justify-center rounded-full bg-primary font-display text-lg font-bold text-primary-foreground">
                {step.number}
              </span>
              <div className="min-w-0">
                <h3 className="font-display text-base font-bold text-foreground">
                  {step.title}
                </h3>
                <p className="mt-0.5 text-sm text-muted-foreground">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
